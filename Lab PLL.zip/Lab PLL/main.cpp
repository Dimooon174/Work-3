#include "rccregisters.hpp"
#include "gpiocregisters.hpp"
#include <iostream>

int main()
{  
  RCC::CR::HSEON::On::Set(); 
  while(!RCC::CR::HSERDY::Ready::IsSet())
  {
  }
  RCC::PLLCFGR::PLLM0::Set(8U); // Set VCO 1 MHz == HSE/8 = 8 000 000 / 8
  RCC::PLLCFGR::PLLN0::Set(128U); // Set VCC Output == 128 Mhz (> 100 Mhz) == VCO * 128 = 1 * 128
  RCC::PLLCFGR::PLLP0::Pllp4::Set(); //Set PLL Output == 32 Mhz == VCO output / 4 = 128 / 4   
  RCC::CR::HSION::Off::Set();
  RCC::CR::PLLON::On::Set();
  while(RCC::CR::PLLRDY::Unlocked::IsSet())
  {
  }
  
  RCC::CFGR::SW::Pll::Set(); 
  while(!RCC::CFGR::SWS::Pll::IsSet())
  {
  }
  
  RCC::AHB1ENR::GPIOCEN::Enable::Set();
  GPIOC::MODER::MODER5::Output::Set();
  for(;;)
  {
    for (int i= 0; i < 1000000 ; i ++)
    {
    }
    
    GPIOC::ODR::ODR5::High::Set() ;
  
    for (int i= 0; i < 1000000 ; i ++)
    {
    }
    GPIOC::ODR::ODR5::Low::Set() ;
  }
  return 1 ;
}
